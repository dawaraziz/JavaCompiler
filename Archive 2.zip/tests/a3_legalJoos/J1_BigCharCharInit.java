// TYPE_CHECKING,CODE_GENERATION
public class J1_BigCharCharInit {

    public J1_BigCharCharInit(){}

	public static int test() {
		char x = (char)123456;
		return x - 57797;
	}
}

