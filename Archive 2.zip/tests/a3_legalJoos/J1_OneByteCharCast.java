// TYPE_CHECKING
public class J1_OneByteCharCast {

    public J1_OneByteCharCast(){}

       public static int test() {

	   return (char)123;
       }
}

