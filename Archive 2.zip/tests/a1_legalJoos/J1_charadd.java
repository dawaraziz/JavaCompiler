// PARSER_WEEDER,CODE_GENERATION
public class J1_charadd {
    public J1_charadd() {}
    public static int test() {
	String s = '2'+'4'+""+'2'+'4';
	//System.out.println(s);
	return Integer.parseInt(s) - 10101;
    }
}
