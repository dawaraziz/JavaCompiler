// PARSER_WEEDER
public class J1_commentsInExp8 {

    public J1_commentsInExp8 () {}

    public static int test() {
	int aaaa = 120;
        return (aaaa) /* Java rocks */ +3;
    }

}
