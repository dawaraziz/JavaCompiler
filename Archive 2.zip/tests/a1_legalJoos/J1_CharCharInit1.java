// PARSER_WEEDER,TYPE_CHECKING
public class J1_CharCharInit1 {

    public J1_CharCharInit1(){}

	public static int test() {
		char x = (char)1;
		return x + 122;
	}
}

