// PARSER_WEEDER
public class J1_protected {

    protected int i;

    public J1_protected () {}

    public static int test() {
        return 123;
    }

}
