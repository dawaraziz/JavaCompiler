// PARSER_WEEDER
public class J1_assignmentExp {

    public J1_assignmentExp() {}

    public static int test() {
	int i = 1*100+2*10+3;
	return i;
    }

}
