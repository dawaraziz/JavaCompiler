// PARSER_WEEDER
public class J1_forinitcast {

    public J1_forinitcast() {}

    public static int test() {
	String String = "Hello";
	for (int i=(String=(String)+(String)"World").length(); String.length()<100; ) {
	    String=(String)+(String)"World";
	}
	return String.length()+23;
    }


}
