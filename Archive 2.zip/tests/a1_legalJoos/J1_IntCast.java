// PARSER_WEEDER
public class J1_IntCast {

    public J1_IntCast(){}

       public static int test() {

	   return (int)123456 - 123333;
       }
}

