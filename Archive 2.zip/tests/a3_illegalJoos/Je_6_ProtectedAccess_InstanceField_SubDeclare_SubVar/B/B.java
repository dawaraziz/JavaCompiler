package B;

public class B extends A.A {
    protected B() {}
    
    protected B(int x) {}
}
