package Test2;

public class Zoo{

    public Zoo(){}

    public static int test(){
	return 123;
    }

}
