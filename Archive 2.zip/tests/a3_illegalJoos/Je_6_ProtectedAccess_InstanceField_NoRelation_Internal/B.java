package p;

public class B extends A {
    public B() {}
}
