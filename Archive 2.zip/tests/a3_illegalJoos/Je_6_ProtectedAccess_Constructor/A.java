package p;

public class A {

    protected A () {}

}
