package java.lang;

public interface Cloneable {
}
