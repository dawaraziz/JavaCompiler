public interface InterfaceExtendClassTest extends QuickTest {

}