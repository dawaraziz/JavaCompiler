// TYPE_CHECKING
public class J1_OneByteIntCast {

    public J1_OneByteIntCast(){}

       public static int test() {

	   return (int)123;
       }
}

