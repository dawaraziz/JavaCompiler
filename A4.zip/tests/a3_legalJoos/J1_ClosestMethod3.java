// TYPE_CHECKING
public class J1_ClosestMethod3 {
	public J1_ClosestMethod3 (){}
	public void a(String o, String s) {
		a("","");
	}
	public void a(String s, Object o) {

	}
	public static int test() { return 123; }
}
