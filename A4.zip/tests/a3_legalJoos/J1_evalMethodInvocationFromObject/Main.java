// TYPE_CHECKING
public class Main {
    
    public Main() {}

    public static int test() {
	return new J1_evalMethodInvocation().foo();
    }
}
