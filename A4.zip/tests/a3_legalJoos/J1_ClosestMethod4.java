// TYPE_CHECKING
import java.io.*;

public class J1_ClosestMethod4 {
	public J1_ClosestMethod4 (){}
	public void a(Serializable s) {
		a("");
	}
	public void a(Cloneable s) {

	}
	public void a(String s) {

	}
	public static int test() { return 123; }
}
