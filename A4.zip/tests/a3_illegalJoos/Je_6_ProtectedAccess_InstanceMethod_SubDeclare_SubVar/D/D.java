package D;

public class D extends C.C {
	protected void instanceMethod_Sub() {}
	
    protected D() {}
}
