package B;

public class B extends A.A {
	public B() {}
}
