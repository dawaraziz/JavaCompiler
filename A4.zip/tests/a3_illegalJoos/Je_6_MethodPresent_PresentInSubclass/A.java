public class A {
    
    public A() {}

    public int testA(){
	return 42;
    }

}
