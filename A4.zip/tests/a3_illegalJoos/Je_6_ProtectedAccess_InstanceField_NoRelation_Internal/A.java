package p;

public class A {
    public A() {}
    
    protected int protected_field = 123;
}
