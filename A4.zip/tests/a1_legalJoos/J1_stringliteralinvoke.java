// PARSER_WEEDER
public class J1_stringliteralinvoke {

    public J1_stringliteralinvoke() {}

    public static int test() {
	int len = "HelloWorld".length();
	return len+113;
    }

}
