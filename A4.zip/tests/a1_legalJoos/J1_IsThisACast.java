// PARSER_WEEDER
public class J1_IsThisACast {

    public J1_IsThisACast () {}

    public static int test () {

	int J1_IsThisACast = 654;
	return (J1_IsThisACast)-531;
    }
}
