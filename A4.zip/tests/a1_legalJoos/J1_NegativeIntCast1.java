// PARSER_WEEDER,CODE_GENERATION
public class J1_NegativeIntCast1 {

    public J1_NegativeIntCast1(){}

       public static int test() {

	   return (int)-456123 + 456246;
       }
}

