// PARSER_WEEDER
public class J1_commentsInExp7 {

    public J1_commentsInExp7 () {}

    public static int test() {
        return (126) /* Java rocks */ -3;
    }

}
