// PARSER_WEEDER,CODE_GENERATION
public class J1_NegativeIntCast2 {

    public J1_NegativeIntCast2(){}

       public static int test() {

	   return 456246 + (int)-456123;
       }
}

