// PARSER_WEEDER,CODE_GENERATION
public class J1_NegativeOneByteByteCast {

    public J1_NegativeOneByteByteCast(){}

       public static int test() {

	   return (byte)-123 + 246;
       }
}

