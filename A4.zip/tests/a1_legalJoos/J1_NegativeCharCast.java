// PARSER_WEEDER,CODE_GENERATION
public class J1_NegativeCharCast {

    public J1_NegativeCharCast(){}

       public static int test() {

	   return (char)-123456 - 7493;
       }
}
