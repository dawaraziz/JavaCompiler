// PARSER_WEEDER,TYPE_CHECKING
public class J1_CharCast {

    public J1_CharCast(){}

       public static int test() {

	   return (char)123456 - 57797;
       }
}

