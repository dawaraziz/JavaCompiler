public class ClassImplementClassTest implements QuickTest {
    public ClassImplementTest() {

    }
}