public class Je_BadConstructorName {
    public static int test() {
        return 123;
    }
    public Je_BadConstructorName(){}
    public AnotherConstructorName(int i){}
}
