package Test;

public class Foo{

    public Foo(){}

    public static int test(){
	return Zoo.test();
    }

}
