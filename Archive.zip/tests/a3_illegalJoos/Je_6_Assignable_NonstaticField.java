//JOOS1:TYPE_CHECKING,ASSIGN_TYPE
//JOOS2:TYPE_CHECKING,ASSIGN_TYPE
//JAVAC:UNKNOWN

public class Je_6_Assignable_NonstaticField {
	public int foo;
	
	public Je_6_Assignable_NonstaticField() {
		this.foo = false;	
	}
	
	public static int test() {
		return 123;
	}
}
