package p;

public class A {

    public A () {}
    
    protected void m() {}
}
