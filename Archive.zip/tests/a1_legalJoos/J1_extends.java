// PARSER_WEEDER
public class J1_extends extends java.io.PrintStream {

    public int y;

    public J1_extends() {}

    public static int test() {
	return 123;
    }
}
