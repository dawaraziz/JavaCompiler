// PARSER_WEEDER
public class J1_forupdatecast {

    public J1_forupdatecast() {}

    public static int test() {
	String String = "Hello";
	for (int i=String.length(); String.length()<100; String=(String)+(String)"World") {}
	return String.length()+23;
    }


}
