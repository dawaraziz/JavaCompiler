// PARSER_WEEDER
public class J1_commentsInExp6 {

    public J1_commentsInExp6 () {}

    public static int test() {
        return (120) /* Java rocks */ + 3;
    }

}
