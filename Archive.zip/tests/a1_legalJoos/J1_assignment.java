// PARSER_WEEDER
public class J1_assignment {

    public J1_assignment() {}

    public static int test() {
	int i = 123;
	return i;
    }
}
