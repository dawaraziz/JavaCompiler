// PARSER_WEEDER
public class J1_forMethodUpdate2 {
	public J1_forMethodUpdate2() {}

	public static int test() {
		Integer foo = new Integer(5);
		for (int i=0; i < 1; foo.hashCode()) {
			if (i == 0) return 123;
		}
		return 0;
	}

	public static void main(String[] args) {
		System.out.println(J1_forMethodUpdate2.test());
	}
}
