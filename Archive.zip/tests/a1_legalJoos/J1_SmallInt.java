// PARSER_WEEDER,CODE_GENERATION
public class J1_SmallInt {

    public J1_SmallInt(){}

       public static int test() {

	   return -2147483648 + 2147483000 + 771;
       }
}

