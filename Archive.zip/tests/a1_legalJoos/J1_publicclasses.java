// PARSER_WEEDER
public class J1_publicclasses {
    public J1_publicclasses() {}
    public static int test() {
	return 123;
    }
}
