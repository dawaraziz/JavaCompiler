// PARSER_WEEDER
public class J1_externalcall {

    public J1_externalcall() {}
    
    public static int test() {
	return new java.lang.Integer(0).intValue()+123;
    }

}
