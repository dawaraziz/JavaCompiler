// PARSER_WEEDER
public class J1_comparisonoperations {
    public J1_comparisonoperations() {}
    public static int test() {
	int x = 51;
	boolean b = (x<87) && (x>42) && (x<=86) && (x>=43) && (x==51) && (x!=52);
	return 123;
    }
}

