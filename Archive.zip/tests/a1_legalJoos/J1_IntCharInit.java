// PARSER_WEEDER
public class J1_IntCharInit {

    public J1_IntCharInit(){}

	public static int test() {
		int x = '*';
		return x + 81;
	}
}

