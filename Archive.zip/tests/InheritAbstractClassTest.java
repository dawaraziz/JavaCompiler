public class InheritAbstractClassTest {
    public InheritAbstractClassTest() {}
    public void draw() {}
}