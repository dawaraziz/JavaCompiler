public class Dawar extends Alfred {
    public Dawar () {

    }
}