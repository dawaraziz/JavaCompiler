// TYPE_CHECKING
public class J1_ShortFromByteInit {

    public J1_ShortFromByteInit(){}

	public static int test() {
		short x = (byte)1;
		return x + 122;
	}
}

