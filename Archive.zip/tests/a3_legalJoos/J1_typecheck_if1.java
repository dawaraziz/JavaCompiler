// TYPE_CHECKING
public class J1_typecheck_if1 {

    public J1_typecheck_if1 () {}

    public static int test() {
	if (true) return 123;
	else return 7;
    }

}
