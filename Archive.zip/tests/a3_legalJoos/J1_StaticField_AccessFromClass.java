// DISAMBIGUATION,TYPE_CHECKING,CODE_GENERATION
public class J1_StaticField_AccessFromClass {
	public J1_StaticField_AccessFromClass() { }
	public static int test() { 
		return Byte.MAX_VALUE - 4;
	}
}
