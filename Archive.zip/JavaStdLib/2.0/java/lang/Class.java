package java.lang;
public class Class {
    public Class() {
    }
}
