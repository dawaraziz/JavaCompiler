public class ClassExtendFinalClass extends FinalClass {
    public ClassExtendFinalClass() {

    }
}