public class DuplicateMethodSign {
    public DuplicateMethodSign() {}
    public void draw(int a, int b);
}