public class SuperClass {
    public SuperClass () {

    }

    public static int move(int a, int b) {
        return true;
    }
}