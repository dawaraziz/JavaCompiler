package java.lang;

public class Thread {
    public Thread() {
    }
    public void interrupt() {
    }
    public static int activeCount() {
        return 1;
    }
}
