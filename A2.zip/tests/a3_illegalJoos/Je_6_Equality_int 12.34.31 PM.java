// JOOS1:TYPE_CHECKING,ASSIGN_TYPE
// JOOS2:TYPE_CHECKING,ASSIGN_TYPE
// JAVAC:UNKNOWN
// 
/**
 * Typecheck:
 * - Type boolean is not assignable to type int
 */
public class Je_6_Equality_int {

    public Je_6_Equality_int() {}

    public static int test() {
	int i = (1==2);
        return 123;
    }

}
