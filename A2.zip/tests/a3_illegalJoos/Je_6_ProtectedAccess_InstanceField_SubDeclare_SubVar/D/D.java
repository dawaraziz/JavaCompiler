package D;

public class D extends C.C {
    protected int instanceField_Sub;
    
    protected D() {}
}
