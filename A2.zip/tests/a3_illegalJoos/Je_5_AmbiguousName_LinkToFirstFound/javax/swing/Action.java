package javax.swing;
public class Action {
    public Action() {
    }
    static String ACCELERATOR_KEY = "42";
}
