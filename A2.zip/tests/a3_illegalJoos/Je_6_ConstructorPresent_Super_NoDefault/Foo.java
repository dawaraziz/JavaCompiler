public class Foo {

    public Foo(String s) {}

}
