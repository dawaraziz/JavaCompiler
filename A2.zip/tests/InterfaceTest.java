public interface InterfaceTest {

}