// PARSER_WEEDER
public class J1_stringliterals {
    public J1_stringliterals() {}
    public static int test() {
	String s1 = "";
	String s2 = "123abcABC$%*~";
	return 123;
    }
}
