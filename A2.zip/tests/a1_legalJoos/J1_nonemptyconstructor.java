// PARSER_WEEDER
public class J1_nonemptyconstructor {

    public J1_nonemptyconstructor () {
	String s = "123";
    }

    public static int test() {
        return 123;
    }

}
