public class J1w_StaticField {
    public J1w_StaticField() {}
      protected static int x;
    public static int test() {
        return 123;
    }
}
