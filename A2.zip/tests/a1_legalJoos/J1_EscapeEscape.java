// PARSER_WEEDER
public class J1_EscapeEscape {
	public J1_EscapeEscape() {}
	
	public static int test() {
		String s = "\\\\\\";
		return s.length()+120;
	}
}
