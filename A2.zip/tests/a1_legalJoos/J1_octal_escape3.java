// PARSER_WEEDER
public class J1_octal_escape3 {
    public J1_octal_escape3() {}
    public static int test() {return (int)'\7'+(int)'\77'+53;}
}
