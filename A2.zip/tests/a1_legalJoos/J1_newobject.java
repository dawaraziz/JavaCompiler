// PARSER_WEEDER
public class J1_newobject {

    public J1_newobject() {}

    public static int test() {
	return 123;
    }

}
