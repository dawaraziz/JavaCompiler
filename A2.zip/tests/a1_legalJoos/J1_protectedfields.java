// PARSER_WEEDER
public class J1_protectedfields {
    public J1_protectedfields() {}
    protected int x;
    public static int test() {
	return 123;
    }
}
