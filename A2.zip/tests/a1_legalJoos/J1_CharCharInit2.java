// PARSER_WEEDER
public class J1_CharCharInit2 {

    public J1_CharCharInit2(){}

	public static int test() {
		char x = '*';
		return x + 81;
	}
}

