// PARSER_WEEDER,CODE_GENERATION
public class J1_negativeintcast3 {

    public J1_negativeintcast3() {}

    public static int test() {
	return -(int)-123;
    }

}
