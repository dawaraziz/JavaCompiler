// PARSER_WEEDER,CODE_GENERATION
public class J1_NegativeOneByteShortCast {

    public J1_NegativeOneByteShortCast(){}

       public static int test() {

	   return (short)-123 + 246;
       }
}

