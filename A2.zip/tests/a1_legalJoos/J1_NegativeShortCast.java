// PARSER_WEEDER,CODE_GENERATION
public class J1_NegativeShortCast {

    public J1_NegativeShortCast(){}

       public static int test() {

	   return (short)-123456 - 7493;
       }
}

