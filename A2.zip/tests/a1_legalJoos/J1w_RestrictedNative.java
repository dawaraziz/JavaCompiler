public class J1w_RestrictedNative {
    public J1w_RestrictedNative() {}
    public static native int m(int i);
    public static int test() {
        return 123;
    }
}
