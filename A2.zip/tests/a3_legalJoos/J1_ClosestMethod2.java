// TYPE_CHECKING
public class J1_ClosestMethod2 {
	public J1_ClosestMethod2 (){}
	public void a(short o) {
		a((short)1);
	}
	public void a(int o) {

	}
	public static int test() { return 123; }
}
