package java.util;

public class Calendar {
    public Calendar() {
    }
    public static int MONDAY = 2;
}
