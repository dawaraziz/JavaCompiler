// DISAMBIGUATION
public class Main {

  public Main() {}

  public static int test() {
    int monday = java.util.Calendar.MONDAY;
    return 123;
  }

}
