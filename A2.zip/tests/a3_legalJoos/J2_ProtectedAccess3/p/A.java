package p;

public class A {
    public A () {}
    
    protected static int sf = 42;
}
